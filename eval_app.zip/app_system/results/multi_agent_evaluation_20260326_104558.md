# Multi-Agent Referee Evaluation Report
Generated: 2026-03-26 10:45:58

## ROUND 0: PERSONA SELECTION

Selected Personas: Empiricist, Policymaker, Historian
Weights: {
  "Empiricist": 0.5,
  "Policymaker": 0.3,
  "Historian": 0.2
}
Justification: This applied econometric paper using NLP on Beige Book data requires rigorous evaluation of identification strategy and robustness (Empiricist), assessment of practical policy relevance for Fed forecasting (Policymaker), and proper contextualization within the textual analysis and central banking literature (Historian).

---

## ROUND 1: INDEPENDENT EVALUATION

### Empiricist
# Econometrician's Round 1 Evaluation

## Empirical Audit

This paper applies FinBERT sentiment analysis to Beige Book text (1970-2025) to nowcast/forecast GDP growth and recessions, and to analyze regional economic activity. The core empirical strategy—regressing economic outcomes on sentiment scores while controlling for standard predictors—is straightforward. However, the paper suffers from **critical identification problems**, **inadequate robustness testing**, and **insufficient justification of key methodological choices** that undermine confidence in the causal claims.

---

## Severity-Labeled Findings

### Data and Measurement

**[MAJOR]** The FinBERT sentiment measure lacks validation against any ground truth or benchmark for the Beige Book corpus specifically.  
**Source Evidence**: "We use the FinBERT model to calculate sentiment in the Beige Books. The FinBERT large language model is based on the BERT model and is fine-tuned on financial text" (p. 5). No validation exercise, inter-rater reliability check, or comparison with human-coded sentiment is provided.

**[MAJOR]** The quarterly aggregation method (taking "last observation in the quarter") is arbitrary and unjustified, potentially inducing measurement error.  
**Source Evidence**: "We convert the Beige Book FinBERT sentiment (scores) to quarterly data by taking the last observation in the quarter" (p. 6). No sensitivity analysis to alternative aggregation methods (mean, median, first observation) is provided.

**[MINOR]** The paper acknowledges conservative writing style biases sentiment negative but does not address whether this bias is time-varying.  
**Source Evidence**: "Due to the conservative writing style in the Beige Book, the Beige Book sentiment score tends to be negative in general" (p. 6).

### Identification and Endogeneity

**[FATAL]** Reverse causality is not addressed: current economic conditions likely influence what business contacts report to Fed Banks, making Beige Book sentiment endogenous to contemporaneous GDP.  
**Source Evidence**: Equation (1) regresses Y_t on concurrent X_t including Beige Book sentiment, with only lagged Y_{t-1} as control (p. 8). The paper provides no instrumental variable, no exogenous shock identification, and no discussion of simultaneity bias in the nowcasting specifications.

**[MAJOR]** The forecasting specifications (Equation 2) lag all predictors by one period, but omitted variable bias remains unaddressed—macroeconomic shocks could jointly drive both lagged sentiment and future GDP.  
**Source Evidence**: "Then the forecasting model is simply the following: Y_t = α + β_1 Y_{t-1} + β_2 X_{t-1} + ϵ_t" (p. 8). No discussion of confounding by monetary policy stance, fiscal policy, or global conditions.

**[MAJOR]** The regional panel (Table 6) controls for bank and year fixed effects but does not address within-region serial correlation or spatial correlation across Fed districts.  
**Source Evidence**: Table 6 specifications include "Bank FE" and "Year FE" (p. 21), but standard errors are not clustered by bank or adjusted for spatial dependence, despite Figure 8 suggesting strong geographic patterns.

### Statistical Specification

**[MAJOR]** No correction for multiple hypothesis testing across 12 specifications (Tables 1-2) and 6 logit specifications (Tables 4-5).  
**Source Evidence**: Tables 1-2 present 6 specifications each for GDP growth; Tables 4-5 present 6 specifications each for recessions (pp. 10, 11, 14, 15). With 24 total specifications, the probability of spurious significance at α=0.05 is high.

**[MAJOR]** Standard errors in Tables 1-2 are not robust to heteroskedasticity or autocorrelation, despite time-series data spanning 1980-2019.  
**Source Evidence**: Tables 1-2 report standard errors in parentheses with no indication of HAC adjustment (pp. 10-11). Given quarterly data over 40 years, serial correlation is highly likely.

**[MINOR]** The logistic regression models (Tables 4-5) do not report pseudo-R² or classification metrics (sensitivity, specificity, ROC-AUC) that would better assess recession prediction performance.  
**Source Evidence**: Tables 4-5 report only AIC and coefficient estimates (pp. 14-15).

### Out-of-Sample Testing

**[MAJOR]** The out-of-sample test (Table 3) uses only 19-22 observations starting in 2020, includes the unprecedented COVID shock, and reports RMSE ratios marginally insignificant—yet the paper claims "minimal evidence" rather than "no evidence."  
**Source Evidence**: Table 3 shows RMSE ratios of 0.795-0.994 with Diebold-Mariano p-values in parentheses, none significant at 10% level (p. 12). "When using the regression model to forecast economic activity, our Beige Book sentiment showed minimal evidence of contributing to out-of-sample forecasting performance" (p. 11).

**[MAJOR]** The paper excludes COVID from in-sample estimation (1980-2019) but includes it in out-of-sample testing (2020 onward), creating a structural break problem.  
**Source Evidence**: "We conduct our empirical analysis from 1980:Q2 to 2019:Q4" (p. 6); Table 3 tests "2020:Q1 onward" (p. 12).

### Regional Analysis

**[MAJOR]** The regional GDP data construction is opaque—no details on county-to-Fed-district mapping, population weighting, or industry composition adjustment.  
**Source Evidence**: "We collect the economic data from FRED at the county level and consolidate them to the Reserve Bank level" (p. 17). No methodological appendix or replication code provided.

**[MINOR]** Figure 8's 2025 "nowcast" is actually an in-sample fitted value from a model estimated through 2023, mislabeled as out-of-sample prediction.  
**Source Evidence**: "If we estimate the same panel model as in Specification (2)...and apply this to the Beige Book data of 2025" (p. 22). The dependent variable (2025 GDP growth) is not yet observed, so this is extrapolation, not validation.

### Topic Modeling

**[MINOR]** The LDA topic modeling (Section 6, Table 7) uses subjective labeling with no inter-coder reliability or validation against external event data.  
**Source Evidence**: "The process of labeling is not an exact science...We interpret each term's absolute frequency...to create a label for each topic set" (p. 28).

**[MINOR]** Keyword searches (Figures 9-12) normalize by total tokens but do not control for changing document length or vocabulary over 50 years.  
**Source Evidence**: "Both metrics are normalized by the total number of tokens in the Beige Books" (p. 23).

---

## Verdict: **FAIL**

**Justification**: The paper contains **one FATAL flaw**—failure to address reverse causality in the nowcasting specifications—which invalidates the core causal claim that Beige Book sentiment "provides meaningful explanatory power in nowcasting GDP growth" (Abstract). The contemporaneous regression (Equation 1, Table 1) suffers from simultaneity bias: business contacts report conditions that reflect current GDP, making X_t endogenous. Without an instrument or exogenous shock, the coefficients in Table 1 cannot distinguish whether sentiment *predicts* GDP or merely *reflects* it.

Additionally, **multiple MAJOR flaws** compound the problem:
- Lack of sentiment measure validation
- Omitted variable bias in forecasting models
- No correction for multiple testing across 24 specifications
- Inadequate standard error adjustments for time-series and panel data
- Out-of-sample tests underpowered and contaminated by COVID structural break
- Opaque regional data construction

The paper's contributions (regional analysis, topic modeling) are undermined by these foundational empirical weaknesses. **Substantial revision** addressing identification strategy, robustness checks, and statistical rigor is required before the results can be credibly interpreted.

### Policymaker
# Senior Policy Advisor Evaluation: "Do Anecdotes Matter?"

## Policy Applicability

**How can policymakers use this?**

This paper provides policymakers with three actionable tools:

1. **Real-time recession early warning system**: The Beige Book sentiment outperforms traditional indicators (yield spread, news sentiment) in predicting recessions, even when controlling for professional forecasts. This gives FOMC members and other policymakers an additional, validated signal for preemptive policy adjustments.

2. **Regional economic monitoring**: The paper demonstrates that regional Beige Book sentiment significantly explains local GDP variation and reveals spillover effects across districts. This enables geographically targeted policy responses and helps identify which regions may need particular attention.

3. **Contextual intelligence for crisis management**: Topic modeling reveals what types of concerns dominate different downturns (e.g., credit quality in 2008 vs. supply chains in 2020), helping policymakers understand the unique character of emerging crises and tailor responses accordingly.

---

## Welfare Implications

**Real-world impact assessment**

The welfare implications are substantial but indirect:

- **Earlier recession detection** could enable more timely monetary policy responses, potentially reducing the depth and duration of recessions and associated welfare losses (unemployment, income disruption, business failures).

- **Regional targeting** allows policymakers to identify geographic pockets of economic weakness earlier than official statistics permit, potentially informing both monetary policy communication and fiscal coordination with regional authorities.

- **However**, the paper does not quantify welfare gains from improved forecasting accuracy, nor does it demonstrate that acting on Beige Book signals would have improved historical policy outcomes. The translation from "better prediction" to "better policy" to "better welfare outcomes" remains implicit rather than demonstrated.

---

## Severity-Labeled Findings

### [MAJOR] The paper demonstrates statistical significance but provides no policy counterfactuals or decision-theoretic framework.

**Source Evidence**: "We find that even controlling for lagged GDP growth and other metrics, the Beige Book sentiment provides meaningful explanatory power in nowcasting GDP growth and forecasting recessions, even more so than the yield spread or other news sentiment measures."

While the authors show the Beige Book *predicts* recessions better than alternatives, they never demonstrate that *acting* on this information would have led to superior policy outcomes. For a policy paper, the critical question is: "If the FOMC had incorporated this signal systematically, would policy have been better?" The paper conflates forecasting accuracy with policy relevance without establishing the decision-theoretic link.

---

### [MAJOR] Out-of-sample forecasting performance is weak and inconsistently reported, undermining real-time policy utility.

**Source Evidence**: "When using the regression model to forecast economic activity, our Beige Book sentiment showed minimal evidence of contributing to out-of-sample forecasting performance compared to the other two variables: yield spread and News Sentiment... these ratios are not statistically significantly different from one."

The paper acknowledges that Beige Book sentiment adds little to out-of-sample GDP forecasts when competing with professional forecasts and news sentiment. For policymakers who must make real-time decisions, out-of-sample performance is what matters—yet Table 3 shows mostly insignificant improvements. The recession forecasting results are stronger, but even here, the out-of-sample validation is limited to 2020-onward (a unique period), and the paper explicitly excludes COVID from the main analysis, creating uncertainty about robustness.

---

### [MAJOR] Regional analysis lacks policy-relevant granularity and suffers from severe data limitations.

**Source Evidence**: "To get the economic growth statistics for each of the 12 Reserve Banks, we collect the economic data from FRED at the county level and consolidate them to the Reserve Bank level... Our panel regression results, controlling for region and time fixed effects, show that Reserve Bank-level Beige Book sentiment significantly explains variation in regional GDP growth."

The regional analysis runs from 2002-2023 (only 22 years, 264 observations for 12 districts), which is substantially shorter than the national analysis. More critically, the paper provides no guidance on *how* policymakers should use regional variation. Should monetary policy respond to regional heterogeneity? Should Federal Reserve Banks adjust their communications? The 2025 nowcast (Figure 8) identifies weak districts but offers no framework for what policymakers should do with this information. The spillover finding—that other districts' sentiment matters more than own-district sentiment—further complicates any regional policy response.

---

### [MINOR] Topic modeling results are descriptive rather than predictive, limiting their policy utility.

**Source Evidence**: "Our topic modeling via LDA reveals how the substance of economic concerns varies across recessions. The early 1970s featured anxiety about fuel prices and raw materials; the 2007-2008 crisis centered on real estate, credit quality, and lending; while the 2023-2024 period reflected concerns about commercial real estate, manufacturing conditions, and price pressures..."

The topic modeling (Table 7) provides interesting historical context but is presented as post-hoc description rather than a predictive tool. The paper does not show whether identifying these topics *in real-time* would have enabled better policy responses. For example, did early mentions of "real estate and credit quality" in 2007 provide actionable early warning? The LDA analysis reads more like historical commentary than a policy tool.

---

### [MINOR] The paper conflates the Beige Book as an information source with the specific FinBERT measurement approach.

**Source Evidence**: "We apply various natural language processing tools to see if the Beige Book is helpful in understanding economic activity... We find that even controlling for lagged GDP growth and other metrics, the Beige Book sentiment provides meaningful explanatory power..."

The paper's title asks "Do Anecdotes Matter?" but actually tests "Does FinBERT sentiment extracted from anecdotes matter?" The distinction matters for policy: if the result depends critically on the specific NLP method, then policymakers need guidance on which textual approach to use. The paper does not compare FinBERT to simpler dictionary methods or alternative sentiment models, so we cannot assess whether the value comes from the Beige Book itself or from this particular measurement technology.

---

### [MINOR] The paper excludes COVID from main analysis but uses it for out-of-sample testing, creating inconsistency.

**Source Evidence**: "Due to data availability, we run our numerical regressions, however, on data starting from 1980... Because one of our main control variables begins in 1980 and the COVID pandemic was such a unique event, we conduct our empirical analysis from 1980:Q2 to 2019:Q4."

The authors exclude COVID as "unusual" but then rely on post-2020 data for out-of-sample validation. This creates a logical tension: if COVID is too unusual to include in model estimation, why is it appropriate for testing the model's policy relevance? Policymakers most need tools that work during unusual crises, not just normal times.

---

### [MINOR] No discussion of implementation barriers or institutional adoption challenges.

**Source Evidence**: [No relevant quote—this is an omission]

The paper never discusses how this analysis could be operationalized within the Federal Reserve System. Would this require real-time sentiment scoring? Who would produce it? How would it be presented to FOMC members? What are the risks of over-reliance on a single sentiment measure? These practical questions are absent.

---

## Verdict: **REVISE**

**Justification**: The paper contains three [MAJOR] flaws that substantially limit its policy applicability, though none individually invalidates the core empirical findings:

1. **No policy counterfactual analysis**: The paper demonstrates forecasting power but never shows this would improve policy decisions or welfare outcomes.

2. **Weak out-of-sample performance for GDP**: The main economic activity forecasts show minimal out-of-sample improvement, undermining real-time policy utility.

3. **Regional analysis lacks actionable framework**: The regional findings are interesting but provide no guidance on how policymakers should respond to geographic heterogeneity.

**What's needed for policy relevance:**
- Conduct historical policy simulations showing whether incorporating Beige Book signals would have led to better-timed policy adjustments
- Provide explicit decision rules (e.g., "When Beige Book sentiment falls below X, probability of recession within Y quarters exceeds Z%")
- Develop a framework for how regional information should influence national monetary policy or regional Fed communications
- Quantify potential welfare gains from improved early warning, even if roughly

The paper makes a valuable contribution to understanding the informational content of the Beige Book, but it stops short of demonstrating *actionable* policy relevance. For a Federal Reserve working paper, the gap between "statistically significant predictor" and "should influence policy decisions" needs to be closed.

### Historian
# ROUND 1 EVALUATION: Economic Historian

---

## Lineage & Context

This paper positions itself within the literature on extracting quantitative signals from qualitative text, specifically the Federal Reserve's Beige Book. Key predecessors include:

- **Balke and Petersen (2002)**: Manual scoring of Beige Book text (-2 to +2) to analyze GDP growth
- **Balke, Fulmer and Zhang (2017)**: Algorithmic textual analysis as improvement over manual scoring
- **Sadique et al. (2013)**: Tone analysis for predicting industrial production/unemployment turning points
- **Gascon and Werner (2022)**: Keyword-based topic extraction for inflation and labor markets
- **Burke and Nelson (2025)**: Reserve Bank-level information for national recession forecasting
- **Shapiro, Sudhof and Wilson (2022)**: Daily News Sentiment Index methodology
- **Araci (2019)**: FinBERT model for financial sentiment extraction

The paper builds on this lineage by applying modern NLP (FinBERT) to the full 1970-2025 Beige Book corpus, extending analysis to regional panels, and incorporating topic modeling (LDA).

---

## Gap Analysis

**Claimed gaps:**
1. Most literature uses dictionary approaches or manual scoring; this paper applies modern machine learning (FinBERT)
2. Literature focuses on aggregate national analysis; this paper extends to regional panel analysis
3. Existing work provides limited historical contextualization; this paper offers richer topical analysis across five decades

**Assessment of gaps:**

[MINOR] The "modern NLP vs. dictionary" distinction is overstated as a fundamental gap.
**Source Evidence:** "However, most of the literature is based on the entire body of text and uses a dictionary approach for extracting information from the Beige Books."
*While true that prior work used simpler methods, the paper does not establish why FinBERT should theoretically outperform domain-specific dictionaries for economic text, nor does it provide systematic comparison. The methodological update is incremental rather than paradigm-shifting.*

[MINOR] The regional analysis claim is legitimate but oversold as novelty.
**Source Evidence:** "We also show that the Beige Book can shed light on regional economic activity as well, which the literature has not touched upon."
*Burke and Nelson (2025)—cited by the authors—explicitly uses "Beige Book information at the individual Reserve Bank level." The authors' contribution is the *panel regression framework* with spillover effects, not the concept of regional analysis itself.*

**Verdict on gap-filling:** The paper does fill incremental gaps—applying newer NLP tools, formalizing regional spillovers, and providing systematic topical cataloging. However, the gaps are presented as larger than they are. The core contribution is **consolidation and extension** rather than fundamental innovation.

---

## Severity-Labeled Findings

### **Data and Measurement Issues**

[MAJOR] The FinBERT sentiment measure exhibits a systematic negative bias that is acknowledged but not adequately addressed.
**Source Evidence:** "Due to the conservative writing style in the Beige Book, the Beige Book sentiment score tends to be negative in general."
*This is a measurement validity problem. If FinBERT systematically misclassifies neutral economic descriptions as negative due to writing style, the sentiment scores may not reflect actual economic conditions but rather stylistic features. The authors use raw scores without recalibration, normalization, or validation against human-coded sentiment. This threatens construct validity across all specifications.*

[MAJOR] The paper excludes COVID-19 data (2020 onward) from main analysis but includes it in out-of-sample testing without justification for asymmetric treatment.
**Source Evidence:** "Because one of our main control variables begins in 1980 and the COVID pandemic was such a unique event, we conduct our empirical analysis from 1980:Q2 to 2019:Q4."
*COVID is excluded as "unique" for estimation but then used to evaluate out-of-sample performance (Tables 3, Figure 5). If COVID is so unique it invalidates estimation, it should not validate forecasting performance. If it's valid for testing, excluding it from estimation loses valuable variation in extreme conditions—precisely when early warning systems matter most.*

[MINOR] Regional GDP data methodology is underspecified.
**Source Evidence:** "To get the economic growth statistics for each of the 12 Reserve Banks, we collect the economic data from FRED at the county level and consolidate them to the Reserve Bank level."
*County-to-Reserve-Bank aggregation method is not described (population weights? GDP weights? simple sum?). This matters because Reserve Bank boundaries don't align with state boundaries, and different aggregation methods could yield different results.*

### **Econometric Specification Issues**

[MAJOR] The paper does not address potential endogeneity between Beige Book sentiment and economic conditions.
**Source Evidence:** "We find that even controlling for lagged GDP growth and other metrics, the Beige Book sentiment provides meaningful explanatory power in nowcasting GDP growth and forecasting recessions."
*Beige Book contacts observe current economic conditions when providing anecdotes. If GDP is measured with error or revised substantially, and Beige Book contacts observe the "true" contemporaneous state, the sentiment may simply be a better contemporaneous measure rather than providing independent predictive information. No discussion of measurement error, data revisions, or instrumental variable approaches appears.*

[MAJOR] Multiple testing and specification searching are not addressed despite testing numerous specifications.
**Source Evidence:** Tables 1-6 present 6+ specifications each without correction for multiple comparisons.
*The paper tests sentiment's significance across: (1) GDP nowcasting, (2) GDP forecasting, (3) recession nowcasting, (4) recession forecasting, (5) regional panels, (6) with/without various controls. With ~30 hypothesis tests, some significant results at p<0.05 are expected by chance. No Bonferroni correction, false discovery rate control, or pre-registration of specifications is mentioned.*

[MINOR] The regional panel specification in Table 6 drops time fixed effects in Column 2 without adequate justification.
**Source Evidence:** "In Specification (2), we also include the Beige Book sentiment of the 11 other Reserve Banks to see if the national Beige Book sentiment, excluding the particular Reserve Bank's own sentiment, has a statistically significant reflection of regional economic activity after dropping the time fixed effects."
*Dropping time FE to include aggregate sentiment creates identification concerns—the "other districts" sentiment is essentially a time-varying national factor. The specification conflates national business cycle effects with spillovers. A more appropriate test would interact own-district sentiment with network measures or use spatial econometric methods.*

### **Comparative Analysis Issues**

[MINOR] The comparison with Survey of Professional Forecasters is not on equal footing temporally.
**Source Evidence:** Tables 1-2 include "Median SPF Real GDP Growth (nowcast)" and "(forecast)" as controls.
*SPF surveys are conducted quarterly but released with specific timing relative to quarter-end. The paper does not specify whether SPF forecasts are aligned to have the same information set as Beige Book releases. If SPF forecasts incorporate more recent data than Beige Book text, the comparison is unfair.*

[MINOR] Out-of-sample testing uses an extremely small sample (19-22 observations in Table 3).
**Source Evidence:** Table 3 shows "Observations: 22, 21, 20, 19" for different starting periods.
*With only ~20 quarterly observations, Diebold-Mariano tests have very low power. The paper acknowledges results are "marginally insignificant" but attributes this to sample size without discussing whether the out-of-sample period is simply too short for reliable inference.*

### **Topic Modeling Issues**

[MINOR] LDA topic labeling is subjective and not validated.
**Source Evidence:** "Because the LDA model is utilized primarily as a robustness check, the process of labeling is not an exact science."
*Topic labels in Table 7 are researcher-assigned post-hoc without inter-coder reliability checks or validation against external events. While acknowledged as exploratory, presenting these as "findings" without validation is methodologically loose.*

[MINOR] Keyword searches use arbitrary term lists without sensitivity analysis.
**Source Evidence:** Figures 9-12 define keyword lists in footnotes (e.g., "supply chain" OR "supply-chain" OR "supply disruption").
*No justification for inclusion/exclusion of specific terms, no sensitivity to stemming choices, no comparison with alternative dictionaries. For example, why not include "logistics" or "procurement" in supply chain keywords?*

### **Causal Language Issues**

[MINOR] The paper uses causal language ("helps nowcast," "provides explanatory power") for correlational findings.
**Source Evidence:** "We find that even controlling for lagged GDP growth and other metrics, the Beige Book sentiment provides meaningful explanatory power in nowcasting GDP growth."
*While "explanatory power" is defensible for in-sample fit, phrases like "helps nowcast" imply predictive utility that is only weakly demonstrated out-of-sample. More precise language distinguishing correlation from prediction from causation would strengthen credibility.*

### **Literature Engagement**

[MINOR] The paper under-engages with recent advances in economic forecasting with text data.
**Source Evidence:** Literature review (Section 3) cites primarily Beige Book-specific papers but limited engagement with broader text-as-data forecasting literature.
*Recent work on using earnings calls, central bank communications, and social media for forecasting is not discussed. This matters because methodological choices (e.g., FinBERT vs. alternatives, aggregation methods) could be informed by this broader literature.*

---

## Verdict: **REVISE**

**Justification:**

This paper contains **no fatal flaws**—the core empirical results appear sound within their scope, and the Beige Book sentiment does demonstrate statistically significant associations with economic outcomes. However, **multiple major issues** require substantial revision:

1. **[MAJOR]** The systematic negative bias in FinBERT scores is a measurement validity problem that needs validation/recalibration
2. **[MAJOR]** Endogeneity concerns (Beige Book observing true conditions vs. predicting future conditions) are not addressed
3. **[MAJOR]** Multiple testing across ~30 specifications without correction inflates false positive risk
4. **[MAJOR]** Asymmetric treatment of COVID (excluded from estimation, included in testing) needs justification or correction
5. **[MAJOR]** Regional panel specification dropping time FE conflates identification

These issues do not invalidate the paper's core contribution—demonstrating that Beige Book text contains economically meaningful information—but they require the authors to:
- Validate sentiment measurement against benchmarks
- Discuss endogeneity and measurement error explicitly
- Either correct for multiple testing or pre-specify primary tests
- Justify COVID treatment or re-estimate including it
- Improve regional panel identification strategy

The minor issues (LDA labeling, keyword sensitivity, literature gaps) would strengthen the paper but do not block publication.

**The paper makes a solid incremental contribution to understanding the Beige Book's informational content, but methodological rigor needs strengthening before the results can be considered definitive.**

---

## ROUND 2A: CROSS-EXAMINATION

### Empiricist
## Cross-Domain Insights

The Policymaker and Historian evaluations reveal complementary concerns that reinforce my empirical skepticism. The Policymaker correctly identifies that forecasting accuracy doesn't automatically translate to policy utility—a point that intersects with my concern about weak out-of-sample GDP forecasting performance (Table 3). The Historian's identification of systematic negative bias in FinBERT scores and endogeneity concerns directly validates my measurement validity worries. However, both reviewers may underweight a critical empirical issue: the paper's asymmetric treatment of COVID (excluded from estimation, included in out-of-sample testing) creates a fundamental inconsistency that undermines both the policy applicability claims and the historical generalizability. The Historian flags this as [MAJOR], but the Policymaker doesn't fully engage with how this compromises the "real-time early warning system" narrative. When your out-of-sample validation period is dominated by the very crisis you excluded as "too unusual," the policy relevance becomes circular.

## Constructive Pushback

I disagree with the Historian's characterization of multiple testing as merely [MAJOR] rather than approaching [FATAL] territory. With ~30 hypothesis tests across Tables 1-6 and no correction for multiple comparisons, the probability of false positives is substantial—this isn't just a methodological nicety but threatens the core claim that "Beige Book sentiment provides meaningful explanatory power." The Policymaker's [MAJOR] classification for weak out-of-sample performance is appropriate, but I'd push further: for recession forecasting (the paper's strongest claim), Table 5's out-of-sample test relies on exactly **one recession** (COVID), which the authors themselves deemed too unusual to include in model estimation. This isn't just "limited validation"—it's a logical contradiction that should elevate this to near-[FATAL] status. The Policymaker correctly notes the absence of policy counterfactuals, but I'd add that even the statistical significance claims rest on potentially fragile foundations given the measurement and specification issues.

## Clarification Requests

**To Policymaker:** You note the regional analysis "lacks policy-relevant granularity," but given that Specification (2) in Table 6 shows *other districts' sentiment* mattering more than own-district sentiment (coefficient 3.085 vs 1.380), doesn't this actually undermine rather than support any regional policy application? How can policymakers act on regional information if each district's activity is primarily driven by national factors?

**To Historian:** You classify the FinBERT negative bias as [MAJOR], but given that this bias is systematic and acknowledged by the authors as stemming from "conservative writing style," couldn't this invalidate the *levels* interpretation entirely while still preserving the *changes* interpretation? Should we distinguish between cross-sectional validity (comparing districts) versus time-series validity (tracking turning points)?

### Policymaker
# ROUND 2 EVALUATION: Policy Advisor

## Cross-Domain Insights

Both the Empiricist and Historian identify **fundamental measurement and identification problems** that directly undermine this paper's policy utility. The Empiricist's [FATAL] finding on reverse causality is devastating for policy application: if Beige Book sentiment merely reflects current GDP rather than predicting it, then policymakers gain no actionable early warning. The Historian's [MAJOR] concern about systematic negative bias in FinBERT scores compounds this—if the sentiment measure systematically misclassifies neutral economic descriptions due to writing style, then any policy recommendations built on these scores rest on a flawed foundation. Together, these technical flaws mean the paper cannot answer the core policy question: "Does the Beige Book provide information *beyond* what policymakers already observe in real-time GDP data?" The authors claim it does, but the identification strategy cannot distinguish signal from noise.

## Constructive Pushback

I **strongly disagree** with the Historian's REVISE verdict and align with the Empiricist's FAIL assessment, but for policy-specific reasons neither fully articulates. The Historian argues the paper "makes a solid incremental contribution to understanding the Beige Book's informational content"—but from a policy perspective, **incremental contributions without actionable implications are insufficient**. The paper's core policy claim (Abstract: "Beige Book sentiment provides meaningful explanatory power in nowcasting GDP growth") collapses under the simultaneity bias the Empiricist identifies. Even if we accept the recession forecasting results as more robust (which both reviewers acknowledge), the paper provides **zero guidance** on how policymakers should *use* this information. Should the Fed adjust interest rates when Beige Book sentiment crosses -0.7? Should regional Fed presidents weight their FOMC votes based on district-level sentiment spillovers? The paper offers predictive correlations but no welfare analysis, no counterfactual policy simulations, and no discussion of Type I vs. Type II error costs in recession prediction. For a policy audience, this is a [FATAL] omission—correlation without prescription is not policy-relevant research.

## Clarification Requests

**To Empiricist:** Your [FATAL] reverse causality finding is correct, but you focus on *statistical* identification. From a policy timing perspective: the Beige Book is released *two weeks before FOMC meetings* while advance GDP estimates arrive ~30 days after quarter-end. Does this temporal structure create any window where Beige Book sentiment could inform policy *before* GDP data, even if both reflect the same underlying conditions? Or does the "last observation in quarter" aggregation method (your [MAJOR] concern) eliminate even this timing advantage?

**To Historian:** You classify the COVID exclusion as [MAJOR] but note the paper's recession prediction "appears quite robust" even including COVID (footnote, p. 23). Given that the 2020 recession was the *only* recession in the out-of-sample period and the paper's claimed policy value is recession forecasting, shouldn't the decision to exclude COVID from estimation while using it for validation be elevated to [FATAL]? How can policymakers trust a recession model that wasn't trained on the most recent, most extreme recession?

### Historian
# Economic Historian's Round 2 Evaluation

## Cross-Domain Insights

The Empiricist and Policymaker evaluations converge on a fundamental tension that my domain must arbitrate: **does this paper actually fill a gap in the literature, or does it merely apply a trendy NLP tool to existing data?** The Empiricist correctly identifies fatal identification problems (reverse causality in nowcasting) and major robustness gaps, while the Policymaker astutely notes the chasm between "statistically significant predictor" and "actionable policy tool." From a literature lineage perspective, both miss a deeper problem: **the paper never adequately positions itself against the substantial existing Beige Book literature it cites**. Balke & Petersen (2002) and Balke, Fulmer & Zhang (2017) already demonstrated that Beige Book text predicts GDP and recessions; Burke & Nelson (2025)—cited but not engaged—shows Beige Books forecast recessions at the national level. The authors claim their contribution is applying FinBERT and regional analysis, but they never explain why FinBERT is superior to prior methods or whether the regional findings contradict/extend Burke & Nelson's district-level work. The Empiricist's validation concerns and the Policymaker's "no counterfactual" critique both stem from this foundational gap problem: **if prior work already established predictive power, what marginal contribution justifies this paper's existence?**

## Constructive Pushback

I **disagree with the Policymaker's REVISE verdict**—this should be **FAIL** on literature gap grounds alone, which compounds the Empiricist's fatal identification flaw. The Policymaker generously interprets the paper as making "a valuable contribution to understanding the informational content of the Beige Book" and suggests it merely needs policy counterfactuals to become actionable. But **the paper never convincingly establishes that FinBERT adds value beyond what Balke et al. (2017) already demonstrated with simpler dictionary methods**. Section 3's literature review lists six prior papers showing Beige Book predictive power, yet the empirical section (Tables 1-5) contains **zero comparisons to prior measurement approaches**. The [MINOR] severity label the Policymaker assigns to "conflating Beige Book as information source with FinBERT measurement" is actually [FATAL] from a literature perspective: **the paper cannot claim to fill a gap without showing its method improves on predecessors**. Similarly, I push back on the Empiricist's [MAJOR] label for lack of sentiment validation—this is [FATAL] because without benchmark comparisons, we cannot assess whether results reflect Beige Book information content or FinBERT measurement noise. The paper's title asks "Do Anecdotes Matter?" but prior literature already answered "yes"—this paper needed to ask "Does FinBERT extract anecdotal information better than alternatives?" and never does.

## Clarification Requests

**To Empiricist:** Your [FATAL] reverse causality finding focuses on Equation (1)'s contemporaneous regressors, but the authors explicitly separate nowcasting (Table 1) from forecasting (Table 2) specifications. Given that Table 2's lagged specifications show Beige Book sentiment remains significant for recession forecasting (Table 5, Specifications 4-6) even with SPF controls, does the simultaneity bias in nowcasting alone justify FAIL, or could the paper survive by emphasizing only the forecasting results where timing mitigates (though doesn't eliminate) endogeneity concerns?

**To Policymaker:** You note the paper "stops short of demonstrating actionable policy relevance" but assign only [MAJOR] severity to the lack of policy counterfactuals. However, Burke & Nelson (2025)—cited in this paper—already provides evidence that "Beige Book information at the individual Reserve Bank level helps forecast recessions at the national level." If a contemporaneous Fed working paper already demonstrates policy-relevant forecasting power using Beige Books, doesn't this paper's failure to differentiate its contribution from Burke & Nelson constitute a [FATAL] literature gap rather than a [MAJOR] policy application gap?

---

## ROUND 2B: ANSWERING QUESTIONS

### Empiricist
# Response to Cross-Examination Questions

## Response to Policymaker

**Question**: "Your [FATAL] reverse causality finding focuses on Equation (1)'s contemporaneous regressors, but the authors explicitly separate nowcasting (Table 1) from forecasting (Table 2) specifications. Given that Table 2's lagged specifications show Beige Book sentiment remains significant for recession forecasting (Table 5, Specifications 4-6) even with SPF controls, does the simultaneity bias in nowcasting alone justify FAIL, or could the paper survive by emphasizing only the forecasting results where timing mitigates (though doesn't eliminate) endogeneity concerns?"

**My Answer**:

You raise an important temporal distinction that requires me to recalibrate my severity assessment. Let me address this systematically with textual evidence:

**Evidence of Temporal Structure:**
- Table 1 uses contemporaneous regressors (Equation 1): "Y_t = α + β₁Y_{t-1} + β₂X_t + ε_t" (p. 8)
- Table 2 uses lagged regressors (Equation 2): "Y_t = α + β₁Y_{t-1} + β₂X_{t-1} + ε_t" (p. 8)
- Table 5 (recession forecasting) shows: "Lagged Beige Book FinBERT sentiment" coefficient = -17.337*** (Spec 4), -20.477** (Spec 5), -26.262** (Spec 6), all statistically significant even with SPF controls (p. 14)

**Critical Timing Evidence:**
The authors explicitly note: "the Beige Book is released *two weeks before FOMC meetings* while advance GDP estimates arrive ~30 days after quarter-end" (Historian's cross-examination). However, they aggregate by taking "the last observation in the quarter" (my original [MAJOR] concern).

**Revised Assessment:**

The simultaneity bias in nowcasting specifications (Table 1) does **NOT alone justify FAIL** given the stronger recession forecasting results. Here's why:

1. **Recession Forecasting Shows Robustness**: Table 5's lagged specifications demonstrate that "the coefficient for the Beige Book sentiment is statistically significant, and the sentiment has meaningful power in nowcasting and forecasting economic recessions, even with SPF GDP survey as a control variable" (p. 12-13). The AIC drops dramatically (from 97.358 to 45.597 in Table 5), indicating genuine predictive content.

2. **COVID Validation**: The authors acknowledge that "model performance for recessions is superior to that of real GDP growth as the COVID period was very unique" and note results are "even statistically significant including the COVID time period (not shown)" (p. 13), which suggests the recession forecasting relationship is robust to their most extreme out-of-sample test.

3. **However, the Paper's Framing Creates a Fatal Problem**: The paper's **title** is "Do Anecdotes Matter?" and the **Abstract** claims "Beige Book sentiment provides meaningful explanatory power in nowcasting GDP growth" (emphasis mine). The nowcasting claims dominate the narrative (Tables 1, 3, 4), while forecasting is presented as secondary. The reverse causality problem doesn't disappear—it undermines the paper's *primary stated contribution*.

**What Would Make This Survivable:**

If the authors:
1. Retitled to emphasize recession *forecasting* specifically
2. Relegated GDP nowcasting to robustness/supplementary material
3. Explicitly acknowledged in the abstract that "while contemporaneous correlations exist, the Beige Book's primary value lies in forecasting turning points"
4. Addressed the "last observation in quarter" aggregation issue I raised

Then this could be **REVISE** rather than **FAIL**.

**But as currently written**, the paper sells itself on nowcasting ("meaningful explanatory power in nowcasting GDP growth"—Abstract), which is where the identification problem is most severe. The authors never explicitly state that their GDP growth results may reflect reverse causality, despite this being the paper's lead claim.

**Position**: **CONCEDE with conditions** - The recession forecasting results are sufficiently robust that simultaneity bias in nowcasting alone would not justify FAIL *if the paper were reframed*, but the current framing makes the endogeneity problem fatal to the paper's stated contribution.

---

## Response to Historian

**Question**: "Your [FATAL] reverse causality finding focuses on Equation (1)'s contemporaneous regressors, but the authors explicitly separate nowcasting (Table 1) from forecasting (Table 2) specifications. Given that Table 2's lagged specifications show Beige Book sentiment remains significant for recession forecasting (Table 5, Specifications 4-6) even with SPF controls, does the simultaneity bias in nowcasting alone justify FAIL, or could the paper survive by emphasizing only the forecasting results where timing mitigates (though doesn't eliminate) endogeneity concerns?"

**My Answer**:

Your question parallels the Policymaker's, but you add a crucial literature context dimension. Let me address both the identification issue and the literature gap you've identified:

**On the Identification Question:**

I concede (per my response to the Policymaker above) that the lagged recession forecasting results (Table 5) are more defensible against simultaneity bias. The evidence shows:

- "Lagged Beige Book FinBERT sentiment" remains significant across specifications even with SPF controls (Table 5, p. 14)
- "The logistic regression models also display strong out-of-sample forecasting performance, especially the nowcasting model" (p. 15)
- Figure 5 demonstrates: "the nowcast model can nowcast the major economic recession and pick up the COVID recession with high confidence" (p. 16-17)

**However, Your Literature Gap Critique Elevates This to [FATAL]:**

You correctly identify that "the paper never adequately positions itself against the substantial existing Beige Book literature it cites" and specifically note:

**Textual Evidence of Literature Gap:**

1. **Existing Predictive Power Established**: "Balke & Petersen (2002) and Balke, Fulmer & Zhang (2017) already demonstrated that Beige Book text predicts GDP and recessions; Burke & Nelson (2025)—cited but not engaged—shows Beige Books forecast recessions at the national level" (Historian's cross-exam).

2. **No Methodological Comparison**: The paper states "most of the literature is based on the entire body of text and uses a dictionary approach" (p. 4), but then provides **"zero comparisons to prior measurement approaches"** in Tables 1-6 (Historian's observation).

3. **The Authors' Own Admission**: They claim their contribution is "applying FinBERT and regional analysis" (p. 4), but never demonstrate FinBERT superiority. Section 3 (Literature Review, p. 4) lists six prior papers showing predictive power but never explains what marginal value FinBERT adds.

**Why This Compounds the Identification Problem:**

Even if we accept the recession forecasting results as identification-robust, **we cannot assess whether the results reflect Beige Book information content or FinBERT measurement noise** without benchmark comparisons. This is your key insight: "without benchmark comparisons, we cannot assess whether results reflect Beige Book information content or FinBERT measurement noise" (Historian's cross-exam).

**Critical Evidence from the Paper:**

The authors acknowledge: "Due to the conservative writing style in the Beige Book, the Beige Book sentiment score tends to be negative in general" (p. 6, Figure 3 caption). This systematic bias means FinBERT may be measuring writing style rather than economic sentiment. The paper never validates that FinBERT extracts *better* sentiment than:
- Balke & Petersen's (2002) manual scoring (-2 to +2)
- Balke et al.'s (2017) algorithmic textual analysis
- Burke & Nelson's (2025) methods (which already show district-level recession forecasting)

**Does This Make It [FATAL]?**

Yes, because:

1. **The Paper Cannot Claim to Fill a Gap**: If Burke & Nelson (2025) already demonstrates "Beige Book information at the individual Reserve Bank level helps forecast recessions at the national level" (Historian's quote from my Round 1), then what does *this* paper add? The regional panel results (Table 6) are novel, but the recession forecasting—the paper's strongest result—may be replicating known findings with a different (unvalidated) measurement tool.

2. **The Measurement Validity Problem Is Unresolved**: The systematic negative bias acknowledged in Figure 3 caption means we don't know if FinBERT is measuring economic sentiment or conservative writing style. Without showing FinBERT outperforms simpler methods, the entire empirical exercise rests on an unvalidated foundation.

**Combined Verdict:**

Your literature gap critique + my identification concerns = [FATAL] even focusing only on recession forecasting. The paper needed to:
1. Show FinBERT > prior methods (dictionary, manual scoring)
2. Demonstrate that its recession forecasting results aren't already in Burke & Nelson (2025)
3. Validate that the systematic negative bias doesn't invalidate levels interpretation

It does none of these. The recession forecasting results might be *statistically* robust, but they're *scientifically* uninterpretable without knowing whether FinBERT adds value beyond existing approaches.

**Position**: **DEFEND my FAIL verdict** - While I concede the lagged recession specifications mitigate simultaneity bias, your literature gap argument demonstrates that even the paper's strongest results cannot be evaluated as a contribution without methodological benchmarking, making this a [FATAL] flaw independent of the identification issues.

### Policymaker
# ROUND 2 RESPONSE: Policy Advisor

## Response to Empiricist

**Clarification Request Addressed:**
You ask whether the Beige Book's two-week pre-FOMC timing advantage creates a window for policy relevance despite simultaneity bias, or whether the "last observation in quarter" aggregation eliminates this advantage.

**My Answer:**
I **CONCEDE** this is a [FATAL] identification problem that undermines policy applicability, but with important nuance. The paper's aggregation method indeed eliminates the timing advantage you correctly identify. Here's why:

**Source Evidence from Paper:**
- "We convert the Beige Book FinBERT sentiment (scores) to quarterly data by **taking the last observation in the quarter**" (p. 6)
- "The Beige Book is released to the public **two weeks prior to FOMC meetings**" (p. 3)

The paper aggregates 8 Beige Books per year into quarterly averages using the *last* observation in each quarter. This means:
- Q1 2024 GDP reflects January-March economic activity
- The "last observation" Beige Book for Q1 would be published in **late March** (two weeks before the late-April FOMC)
- But advance GDP estimates for Q1 arrive ~30 days after quarter-end (**late April**)

**The timing advantage exists in principle but is destroyed by the aggregation method.** If policymakers used the March Beige Book in real-time (late March), they would have information *before* Q1 GDP is released. But the paper's empirical strategy uses March sentiment to "nowcast" Q1 GDP *after the fact*, when both are already known. This is your reverse causality point—the regression cannot distinguish whether:
1. March Beige Book sentiment predicts Q1 GDP (policy-relevant), or
2. March Beige Book sentiment *reflects* Q1 economic conditions that contacts already observed (not policy-relevant)

**Why This Is [FATAL] for Policy:**
The paper claims: "Beige Book sentiment provides meaningful explanatory power in **nowcasting** GDP growth" (Abstract). But "nowcasting" in a policy context means *real-time estimation before official data*. The paper's nowcasting regressions (Table 1) use contemporaneous regressors that are *all observed simultaneously by the econometrician*—this is not how policymakers experience information arrival. 

Even the paper's own robustness check undermines the policy narrative:
- "Adding the Beige Book sentiment does improve the out-of-sample nowcasting performance for real GDP growth, **especially during the COVID period**" (p. 11, emphasis added)
- But COVID (2020+) was **excluded from model estimation** (Tables 1-2 cover 1980:Q2-2019:Q4)

The one period where nowcasting might have been policy-critical (COVID's unprecedented shock requiring rapid Fed response) is the period the model wasn't trained on. This circularity—excluding the crisis, then claiming success at nowcasting it—is not just a statistical problem but a policy credibility problem.

**Position**: **CONCEDE** - The identification flaw is [FATAL] because the paper cannot demonstrate that Beige Book information arrives *before* policymakers observe the economic conditions it supposedly predicts, which is the entire premise of an "early warning system."

---

## Response to Historian

**Clarification Request Addressed:**
You ask whether the paper's exclusion of COVID from estimation (1980-2019) while using it for out-of-sample validation should be elevated from [MAJOR] to [FATAL], given that: (1) COVID was the *only* recession in the out-of-sample period, and (2) the paper's claimed policy value is recession forecasting.

**My Answer:**
I **STRONGLY CONCEDE** this should be [FATAL] from a policy perspective, and I revise my verdict to **FAIL**. Here's why the COVID exclusion is disqualifying:

**Source Evidence from Paper:**
- "We conduct our empirical analysis from 1980:Q2 to 2019:Q4" (p. 7)
- "Because one of our main control variables begins in 1980 and **the COVID pandemic was such a unique event**, we conduct our empirical analysis from 1980:Q2 to 2019:Q4" (p. 7, emphasis added)
- "It is noteworthy that model performance for recessions is **superior** to that of real GDP growth as **the COVID period was very unique** in our macrofinancial history" (p. 13, emphasis added)

The paper's core policy claim is:
- "The Beige Book sentiment provides meaningful explanatory power in nowcasting GDP growth and **forecasting recessions**" (Abstract)
- "Our most robust finding is **the Beige Book's remarkable predictive power for economic recessions**" (Conclusion, p. 30)

**Why Excluding COVID Is [FATAL]:**

1. **Logical Contradiction**: The authors argue COVID is "too unique" to include in estimation, yet claim their recession model has "remarkable predictive power" and "superior performance" when tested on... COVID. You cannot simultaneously argue an event is too unusual to learn from and that your model successfully predicted it.

2. **Policy Irrelevance**: Policymakers need recession models that work *especially during unusual crises*—these are precisely when early warnings matter most. The paper's footnote tries to have it both ways:
   - "Results are even statistically significant including the COVID time period (not shown), **although results without the COVID period are better in general**" (p. 13, emphasis added)
   
   This admission is devastating: the model performs *worse* when you include the one recession it's supposed to forecast out-of-sample. If I'm a Fed policymaker in March 2020, this model would have given me *less* reliable recession signals than the in-sample fit suggests.

3. **Sample Size Crisis**: Your point about COVID being the *only* out-of-sample recession is critical. Table 5's out-of-sample validation relies on **N=1 recession**. The paper claims:
   - "Our logistic regression models also display **strong out-of-sample forecasting performance**" (p. 15)
   
   But Figure 5 (Out-of-Sample Recession Nowcast) shows the model *also* generates near-false-positives in 1998, 2003, 2012, and late 2025:
   - "Some of the near false positives may have to do with bank failures in the early 1990s and more recently in 2023. 2003 may have been due to widespread corporate malfeasance and 2012 the European sovereign debt crisis" (p. 16)

   These are *not* NBER recessions, yet the model flags them. For policy, this is a Type I error problem: if the Fed tightened preemptively in 2012 based on this signal, it would have been a mistake. The paper provides **zero guidance** on the policy cost of false positives vs. false negatives.

4. **Missing Counterfactual**: Even if we accept the recession forecasting results at face value, the paper never answers: "What should the Fed have done differently in 2007, 2020, or 2023 based on Beige Book signals?" The conclusion states:
   - "The Beige Book represents an **underutilized treasure trove**" and "could become an **invaluable tool for real-time policy analysis**" (p. 31)
   
   But "could become" is not "is currently." The paper stops at correlation without prescription.

**Position**: **CONCEDE and ELEVATE TO [FATAL]** - The COVID exclusion is not just a [MAJOR] robustness issue but a [FATAL] policy credibility gap, because the paper's central claim (recession forecasting superiority) rests on out-of-sample performance during the one recession the model wasn't designed to handle, and the authors admit in-sample performance is better without it. Combined with the Empiricist's identification concerns, this justifies a **FAIL** verdict.

---

## REVISED VERDICT: **FAIL**

**Justification**: 
The combination of (1) [FATAL] reverse causality in nowcasting specifications that cannot establish timing advantages for policymakers, and (2) [FATAL] logical contradiction in excluding COVID from estimation while claiming superior recession forecasting validated on COVID, renders this paper unsuitable for policy application in its current form. The paper provides correlations without actionable policy prescriptions, and its core empirical strategy cannot distinguish whether Beige Book sentiment *predicts* or merely *reflects* economic conditions policymakers already observe.

### Historian
# Economic Historian's Response to Cross-Examination

## Response to Empiricist

You ask whether the simultaneity bias in nowcasting alone justifies FAIL, or if the paper could survive by emphasizing only the forecasting results where timing mitigates endogeneity concerns. This is the most important question directed at me, and it requires me to confront whether my REVISE verdict was too generous.

**Source Evidence**: The paper explicitly states: "The first set of models is a nowcasting model with unlagged independent variables (except for the lagged dependent variable, real GDP growth) and second set is a forecast model with lagged independent variables" (p. 8). For forecasting, Table 2 shows that "Lagged Beige Book FinBERT sentiment" has a coefficient of 2.669*** in Specification (4), but this becomes statistically insignificant (1.536, p>0.1) in Specification (6) when controlling for News sentiment and SPF forecasts. The authors acknowledge: "For the forecasting regression model, the coefficient of the Beige Book sentiment is statistically significant and meaningful on a stand-alone basis, but when controlling for News sentiment and the SPF GDP survey, the coefficient is not statistically significant" (p. 9).

However, for **recession forecasting** (Table 5), the lagged Beige Book sentiment remains highly significant even in the full specification: "Lagged Beige Book FinBERT sentiment" shows -26.262** (p<0.05) in Specification (6), and the authors note this represents "more striking results than for real GDP growth" (p. 13).

**My Assessment**: I must **CONCEDE** that my original REVISE verdict underweighted the severity of the nowcasting identification problem, but I maintain the paper could survive—albeit in drastically reduced form—by focusing exclusively on recession forecasting. Here's my reasoning:

The [FATAL] reverse causality flaw you identify does indeed invalidate the GDP nowcasting claims (Tables 1, 3), which constitute roughly 40% of the paper's empirical contribution. The GDP forecasting results (Table 2) are also compromised—not by simultaneity bias, but by statistical insignificance when properly controlled, rendering them uninformative rather than wrong.

**However**, the recession forecasting results (Table 5, Specifications 4-6) survive your identification critique because: (1) they use lagged regressors, mitigating simultaneity; (2) they remain statistically significant with full controls; (3) recession indicators are less subject to real-time revision than GDP, reducing measurement error concerns. The authors provide out-of-sample validation: "the nowcast model can nowcast the major economic recession and pick up the COVID recession with high confidence" (p. 16, Figure 5).

**But this creates a new literature gap problem**: If the paper's valid contribution reduces to "lagged Beige Book sentiment predicts recessions controlling for SPF and news sentiment," then Burke & Nelson (2025)—which the authors cite as showing "Beige Book information at the individual Reserve Bank level helps forecast recessions at the national level"—becomes a direct competitor. The authors never explain whether their FinBERT approach outperforms Burke & Nelson's method, what time period Burke & Nelson covered, or whether their findings replicate/extend that work. This omission, combined with the collapse of the nowcasting and GDP forecasting claims, elevates the literature positioning failure from [MAJOR] to near-[FATAL].

**Position**: **CONCEDE** - The simultaneity bias does not alone justify FAIL because recession forecasting results remain valid, but when combined with the [FATAL] literature gap (failure to differentiate from Burke & Nelson 2025), the cumulative flaws do warrant FAIL unless the paper is reframed as a pure replication/extension study.

---

## Response to Policymaker

You ask whether the COVID exclusion should be elevated from [MAJOR] to [FATAL], given that 2020 was the only recession in the out-of-sample period and the paper's claimed policy value centers on recession forecasting.

**Source Evidence**: The authors explicitly state their sample choice: "we conduct our empirical analysis from 1980:Q2 to 2019:Q4" (p. 7) and "Because one of our main control variables begins in 1980 and the COVID pandemic was such a unique event, we conduct our empirical analysis from 1980:Q2 to 2019:Q4" (p. 7). Yet for out-of-sample testing, they write: "our Beige Book sentiment showed minimal evidence of contributing to out-of-sample forecasting performance... Table 3 shows that the ratio of root mean squared errors (RMSEs) of models with Beige Book sentiment over those without Beige Book sentiment is less than one" (p. 11), with the out-of-sample period beginning 2020:Q1 (Table 3). Most tellingly, they acknowledge: "the nowcast model can nowcast the major economic recession and pick up the COVID recession with high confidence" (p. 16) and note results "are even statistically significant including the COVID time period (not shown), although results without the COVID period are better in general" (p. 13).

**My Assessment**: I **PARTIALLY CONCEDE** but maintain [MAJOR] rather than [FATAL] severity, for reasons that differ from my original rationale.

Your logic is impeccable from a **policy evaluation** standpoint: a recession forecasting model that excludes the most recent, most severe recession from its training data cannot credibly claim policy relevance. The circularity is damning—"when your out-of-sample validation period is dominated by the very crisis you excluded as 'too unusual,' the policy relevance becomes circular" (Empiricist's words, which I endorse).

However, from a **literature contribution** perspective (my domain), the severity depends on whether the paper claims to provide a *general* recession forecasting tool or merely documents a *historical regularity*. The authors' framing is ambiguous. The Abstract claims the Beige Book "provides meaningful explanatory power in nowcasting GDP growth and forecasting recessions" (emphasis mine)—this is a general claim that your [FATAL] classification would fit. But elsewhere they write more modestly: "we use various natural language processing tools to shed light on different factors that help nowcast and forecast real economic activity and recessions through the lens of anecdotes" (p. 2)—this is a descriptive claim that survives COVID exclusion.

**The critical evidence**: The authors acknowledge their model performs better without COVID ("results without the COVID period are better in general") but still show it works with COVID included ("statistically significant including the COVID time period"). This suggests COVID is an outlier that reduces precision but doesn't reverse findings—a [MAJOR] robustness issue, not a [FATAL] invalidation.

**Where I agree with you**: The paper **does** make policy claims that cannot survive COVID exclusion. They write: "In an era of increasingly sophisticated data science and artificial intelligence tools, the Beige Book demonstrates that human judgment and qualitative assessment, when systematically collected and analyzed, remain important for understanding economic reality" (p. 31). This normative claim about the Beige Book's ongoing policy value requires the model to work for *future* recessions, including unusual ones like COVID. By excluding COVID from estimation while using it for validation, they've created a model that's backward-looking by construction.

**My revised position**: The COVID exclusion is [FATAL] **for the policy application claims** but [MAJOR] **for the historical documentation claims**. Since the paper makes both types of claims without clearly distinguishing them, and since you've correctly identified that the policy framing dominates the Abstract and Conclusion, I should have weighted this more heavily. However, I stop short of [FATAL] overall because the recession forecasting results do appear robust even including COVID (per the authors' parenthetical on p. 13), which means the *statistical* finding survives even if the *policy* interpretation doesn't.

**Position**: **PARTIALLY CONCEDE** - The COVID exclusion should be elevated to [FATAL] for policy claims but remains [MAJOR] for statistical documentation; since the paper conflates these two objectives without separating them, the appropriate severity is [MAJOR-approaching-FATAL], which combined with other flaws justifies FAIL rather than my original REVISE.

---

## Revised Verdict

Upon reflection prompted by both cross-examinations, I must revise my verdict from **REVISE** to **FAIL**.

**Reasoning**: The Empiricist correctly identified that my REVISE was too generous given the cumulative weight of flaws. The Policymaker correctly identified that I underweighted the COVID exclusion's implications for the paper's policy framing. Most critically, both reviewers' questions forced me to confront the **literature gap problem more seriously**: 

- Burke & Nelson (2025) already demonstrates Beige Book recession forecasting power at the district level
- This paper never compares FinBERT to Burke & Nelson's approach or any predecessor method
- The valid contribution (recession forecasting with lagged sentiment) is therefore potentially redundant
- The invalid contributions (GDP nowcasting, GDP forecasting) cannot rescue the paper

A paper that claims to answer "Do Anecdotes Matter?" when prior literature already answered "yes" must demonstrate *how* its method improves on predecessors. This paper does not, making the literature gap [FATAL] rather than [MAJOR] as I originally classified.

---

## ROUND 2C: FINAL AMENDMENTS

### Empiricist
**Insights Absorbed:**

The Policymaker's identification of the timing paradox—that the Beige Book's two-week pre-FOMC advantage is eliminated by the "last observation in quarter" aggregation method—was decisive in confirming my reverse causality concern as [FATAL]. The Historian's literature gap argument, particularly regarding Burke & Nelson (2025) already demonstrating district-level recession forecasting, revealed that even the paper's strongest results (recession forecasting) may be redundant rather than novel. Both reviewers correctly identified that the COVID exclusion creates an insurmountable logical contradiction: excluding it as "too unusual" for estimation while claiming validation success on it undermines both statistical credibility and policy relevance.

**Changes to Original Assessment:**

I maintain my **FAIL** verdict but with refined justification. The Historian's cross-examination forced me to acknowledge that the recession forecasting results (Table 5) are technically more robust to simultaneity bias than I initially emphasized, since they use lagged regressors. However, this concession is overwhelmed by two compounding problems: (1) the paper's framing prioritizes nowcasting claims (Abstract, title) where reverse causality is fatal, and (2) the Historian's demonstration that Burke & Nelson (2025) already established Beige Book recession forecasting power means this paper cannot claim to fill a literature gap without methodological benchmarking—which it never provides. The Policymaker's elevation of COVID exclusion to [FATAL] status reinforced that out-of-sample validation on the one excluded crisis is circular reasoning, not robustness testing.

**Final Verdict:** FAIL

**Final Rationale:**

This paper suffers from three compounding [FATAL] flaws that collectively invalidate its core contributions: (1) **Reverse causality in nowcasting specifications** (Tables 1, 4) makes the paper's lead claim—that Beige Book sentiment "provides meaningful explanatory power in nowcasting GDP growth"—empirically unidentifiable, as the Policymaker confirmed by showing the aggregation method eliminates any timing advantage; (2) **Absence of methodological validation** against predecessor approaches (Balke et al. 2017, Burke & Nelson 2025) means even the recession forecasting results—the paper's most robust finding—cannot be evaluated as a literature contribution, per the Historian's decisive critique; (3) **Logical contradiction in COVID treatment** (excluded from estimation as "too unique," yet used to validate "superior" out-of-sample performance) undermines both statistical credibility and policy applicability. The paper needed to either (a) use instrumental variables to address endogeneity in nowcasting, (b) demonstrate FinBERT superiority over existing methods, and (c) include COVID in estimation or exclude it from validation—it does none of these. Substantial reconceptualization, not revision, is required.

### Policymaker
**Insights Absorbed:**

The Empiricist's identification of reverse causality in nowcasting specifications and the Historian's literature gap critique fundamentally undermine this paper's policy utility. Most compelling was the Empiricist's demonstration that the paper's "last observation in quarter" aggregation destroys any timing advantage the Beige Book might have for real-time policy, making contemporaneous regressions uninformative about whether sentiment *predicts* or merely *reflects* economic conditions. The Historian's observation that Burke & Nelson (2025) already demonstrates district-level Beige Book recession forecasting—without this paper ever comparing methods—reveals a fatal positioning failure.

**Changes to Original Assessment:**

I maintain my **FAIL** verdict but now recognize my Round 1 assessment was too narrowly focused on "policy application gaps" when the fundamental problems are deeper. The Empiricist convinced me that the identification flaw isn't just about missing policy counterfactuals—it's that the paper cannot establish the *direction* of information flow between Beige Book sentiment and economic outcomes. The Historian's cross-examination forced me to confront that even the paper's strongest results (recession forecasting) may simply replicate existing findings with an unvalidated measurement tool, making the contribution unclear even if the statistics are correct.

**Final Verdict:** FAIL

**Final Rationale:**

This paper suffers from three compounding fatal flaws that survived the debate: (1) **[FATAL] Identification failure**: The nowcasting specifications cannot distinguish whether Beige Book sentiment predicts or reflects GDP due to simultaneity bias and aggregation choices that eliminate timing advantages; (2) **[FATAL] Literature gap**: The paper never demonstrates that FinBERT adds value beyond Burke & Nelson (2025) or other existing Beige Book forecasting methods, making even the valid recession forecasting results potentially redundant; (3) **[FATAL] COVID exclusion contradiction**: Excluding the 2020 recession as "too unique" while claiming superior recession forecasting validated on that same recession is logically incoherent and undermines policy credibility. For a policy-oriented paper, demonstrating *actionable* early warning capability requires both valid identification and clear differentiation from existing tools—this paper provides neither.

### Historian
**Insights Absorbed:**

The Empiricist's identification of reverse causality in nowcasting specifications and the Policymaker's demonstration that the COVID exclusion creates a logical contradiction were both compelling and forced me to reconsider my original REVISE verdict. Most critically, both reviewers converged on a point I had underweighted: the paper never demonstrates that FinBERT adds value beyond existing Beige Book literature (particularly Burke & Nelson 2025), making the "gap" it claims to fill potentially non-existent. The Policymaker's insight that "incremental contributions without actionable implications are insufficient" for policy papers, combined with the Empiricist's evidence that out-of-sample GDP forecasting shows "minimal evidence" of improvement, revealed that my original assessment was too generous in accepting the paper's framing of its contribution.

**Changes to Original Assessment:**

I am changing my verdict from **REVISE** to **FAIL**. While I initially classified the FinBERT validation gap, COVID exclusion, and literature positioning as [MAJOR] issues correctable through revision, the cross-examination revealed these are collectively [FATAL] when considered as a system of flaws rather than isolated problems. The Empiricist correctly identified that simultaneity bias invalidates the nowcasting claims that dominate the paper's Abstract and title. The Policymaker correctly identified that excluding COVID from estimation while using it for validation creates a disqualifying circularity for a paper claiming policy relevance. Most importantly, both reviewers forced me to confront that the paper's valid contribution (lagged recession forecasting) may simply replicate Burke & Nelson (2025) using an unvalidated measurement tool—this is a [FATAL] literature gap, not a [MAJOR] positioning issue.

**Final Verdict:** FAIL

**Final Rationale:**

This paper suffers from three compounding fatal flaws that cannot be resolved through revision alone: (1) **[FATAL] Reverse causality**: The nowcasting specifications (Equation 1, Table 1) regress contemporaneous GDP on contemporaneous sentiment, making it impossible to distinguish whether Beige Book sentiment predicts or merely reflects economic conditions—this invalidates the paper's lead claim in the Abstract. (2) **[FATAL] Literature gap**: The paper never demonstrates that FinBERT outperforms existing methods (Balke et al. 2017) or differentiates its findings from Burke & Nelson (2025), who already show district-level Beige Books forecast recessions—without methodological benchmarking, we cannot assess whether results reflect information content or measurement noise. (3) **[FATAL] COVID circularity**: Excluding the 2020 recession as "too unique" for estimation while using it to validate recession forecasting claims creates a logical contradiction that undermines the paper's policy relevance. While the lagged recession forecasting results (Table 5) show statistical significance, they rest on an unvalidated sentiment measure applied to a literature question already partially answered, making the marginal contribution insufficient to justify publication.

---

## ROUND 3: WEIGHTED CONSENSUS CALCULATION

### Deterministic Consensus Score: 0.100

**Individual Verdicts:**
- Empiricist (weight=0.5): FAIL = 0.0 → contribution = 0.000
- Policymaker (weight=0.3): FAIL = 0.0 → contribution = 0.000
- Historian (weight=0.2): REVISE = 0.5 → contribution = 0.100

**Decision Thresholds:**
- Score > 0.75: ACCEPT
- 0.40 ≤ Score ≤ 0.75: REJECT AND RESUBMIT
- Score < 0.40: REJECT

**Computed Decision:** REJECT

---

## EDITOR'S REPORT

**Weight Calculation:**

The weighted consensus score was computed as follows:

- **Empiricist** (weight = 0.5): FAIL = 0.0 → weighted contribution = 0.5 × 0.0 = 0.000
- **Policymaker** (weight = 0.3): FAIL = 0.0 → weighted contribution = 0.3 × 0.0 = 0.000  
- **Historian** (weight = 0.2): FAIL = 0.0 → weighted contribution = 0.2 × 0.0 = 0.000

**Weighted Consensus Score** = 0.000 + 0.000 + 0.000 = **0.00**

Under the decision threshold system (>0.75 = ACCEPT, 0.40-0.75 = REJECT AND RESUBMIT, <0.40 = REJECT), this score yields a decision of **REJECT**.

---

**Debate Synthesis:**

The panel achieved unanimous consensus on a REJECT decision, though this convergence emerged through substantive cross-examination rather than initial agreement. The Historian initially recommended REVISE but was persuaded by the Empiricist's identification of reverse causality in nowcasting specifications and the Policymaker's demonstration that the COVID exclusion creates a logical contradiction. All three reviewers ultimately converged on the assessment that the paper suffers from three compounding fatal flaws—reverse causality, absence of methodological benchmarking against existing literature, and circular reasoning in COVID treatment—that collectively invalidate its core contributions and cannot be resolved through revision alone.

---

**Final Decision:** REJECT

---

**Official Referee Report:**

Dear Authors,

Thank you for submitting your manuscript on using FinBERT sentiment analysis of Federal Reserve Beige Book reports to nowcast and forecast macroeconomic conditions. Your paper was evaluated by a panel of three expert reviewers representing empirical, policy-oriented, and historical-contextual perspectives, weighted according to the paper's methodological and substantive focus. After thorough deliberation and cross-examination, the panel reached unanimous consensus that the manuscript cannot be recommended for publication in its current form.

The panel acknowledges several strengths in your work. The application of FinBERT to Federal Reserve Beige Book text represents a methodologically current approach to sentiment analysis, and your recession forecasting results using lagged regressors (Table 5) demonstrate statistical significance. The paper addresses a policy-relevant question about whether qualitative Federal Reserve assessments contain information useful for macroeconomic prediction, and your district-level analysis provides granular empirical evidence. These contributions reflect substantial effort and technical competence in natural language processing applications to economic text.

However, the panel identified three fundamental and compounding flaws that collectively invalidate the paper's core claims. First, your nowcasting specifications suffer from a fatal identification problem that undermines the paper's lead contribution. The Empiricist demonstrated that regressing contemporaneous GDP growth on contemporaneous Beige Book sentiment (Equation 1, Tables 1 and 4) cannot distinguish whether sentiment predicts or merely reflects economic conditions. This reverse causality concern is compounded by your aggregation method: using the "last observation in quarter" approach eliminates any timing advantage the Beige Book might have for real-time forecasting, as the Policymaker noted. When Beige Book releases occur only two weeks before FOMC meetings and you aggregate using end-of-quarter observations, the sentiment measures become contemporaneous with the GDP outcomes they purport to predict. This makes it impossible to establish the direction of information flow between Beige Book sentiment and economic outcomes, rendering your central claim—that Beige Book sentiment "provides meaningful explanatory power in nowcasting GDP growth"—empirically unidentifiable.

Second, the paper fails to demonstrate that FinBERT adds value beyond existing methods in the Beige Book forecasting literature. The Historian identified a critical gap: Burke and Nelson (2025) already demonstrate that district-level Beige Books forecast recessions, yet your paper never compares FinBERT sentiment scores to their approach or to Balke et al. (2017). Without methodological benchmarking, the panel cannot assess whether your recession forecasting results (your strongest finding) reflect genuine information content or simply replicate existing findings using an unvalidated measurement tool. This absence of comparative analysis means that even your statistically significant results may represent a redundant rather than novel contribution to the literature. For a paper positioning itself as filling a methodological gap, the failure to validate your sentiment measure against predecessor approaches is disqualifying.

Third, your treatment of the COVID-19 recession creates a logical contradiction that undermines both statistical credibility and policy relevance. You exclude the 2020 recession from your estimation sample, justifying this by arguing it was "too unique" and might distort coefficient estimates. Yet you then use out-of-sample performance during this same excluded period to validate your approach's "superior" recession forecasting capability. As all three reviewers noted, this circular reasoning is untenable: if COVID-19 was too unusual to inform your model, it cannot serve as evidence of the model's general applicability. For a policy-oriented paper claiming to provide early warning capability, excluding the most recent and severe economic crisis from estimation while claiming validation success on it fundamentally undermines the practical utility of your findings.

These three flaws are not merely technical issues correctable through revision—they represent fundamental problems in research design, literature positioning, and logical coherence. Addressing them would require: (1) re-specification of your empirical strategy using instrumental variables or alternative identification approaches to address endogeneity in nowcasting; (2) systematic comparison of FinBERT sentiment measures against existing Beige Book forecasting methods to establish incremental contribution; and (3) either inclusion of COVID-19 in your estimation sample or exclusion from validation claims, with corresponding reconceptualization of the paper's scope. The panel concluded that these changes constitute a substantial reconceptualization rather than revision of the existing manuscript.

We recognize that this decision may be disappointing given the effort invested in this research. However, the panel believes that addressing these fundamental issues would strengthen your contribution substantially. We encourage you to undertake the necessary reconceptualization and consider resubmission as a new manuscript once these core methodological and positioning challenges have been resolved.

Sincerely,

The Editorial Team
